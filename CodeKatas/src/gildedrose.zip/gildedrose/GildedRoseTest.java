package gildedrose;

import org.junit.Test;

public class GildedRoseTest {





}
