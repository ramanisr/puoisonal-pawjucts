package gildedrose;


public class Constants {
	
	public static String AGED_BRIE= "Aged Brie";
	public static String SULFURAS = "Sulfuras, Hand of Ragnaros";
	public static String BACKSTAGE_PASSES = "Backstage passes to a TAFKAL80ETC concert";
	public static String CONJURED = "Conjured Mana Cake";
}
